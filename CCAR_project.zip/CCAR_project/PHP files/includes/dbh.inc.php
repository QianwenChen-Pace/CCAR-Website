<?php
//Setting Database Variables
$dbServername="localhost";
$dbUsername="root";
$dbPassword="";
$dbName="ccar";
//creating the connection
$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);