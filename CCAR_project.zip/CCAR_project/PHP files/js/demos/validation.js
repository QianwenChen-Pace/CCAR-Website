$(function () {
  
  $('#demo-validation').submit (function (e) {
    e.preventDefault ()
  })

})