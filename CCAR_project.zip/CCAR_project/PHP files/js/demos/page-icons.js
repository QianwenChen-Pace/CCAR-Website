$(function () {
  
  $('.fontawesome-icon-list a').click (function (e) {
    e.preventDefault ()
  })

})